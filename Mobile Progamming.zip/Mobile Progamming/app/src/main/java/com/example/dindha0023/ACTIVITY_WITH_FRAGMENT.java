package com.example.dindha0023;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class ACTIVITY_WITH_FRAGMENT extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity__with__fragment);
    }


    public void fr1(View view) {
        android.support.v4.app.FragmentTransaction ft = getSupportFragmentManager().beginTransaction();

        ft.replace (R.id.framefragment, new BlankFragment1());

        ft.commit();
    }

    public void fr2(View view) {
        android.support.v4.app.FragmentTransaction ft = getSupportFragmentManager().beginTransaction();

        ft.replace (R.id.framefragment, new BlankFragment2());

        ft.commit();
    }
    }

